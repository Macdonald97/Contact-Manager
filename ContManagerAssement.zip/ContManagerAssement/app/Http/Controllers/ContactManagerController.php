<?php

namespace App\Http\Controllers;

use App\Models\ContactManager;
use Illuminate\Http\Request;

class ContactManagerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
	
    {
         $details = ContactManager::latest()->paginate(5);
      
        return view('details.index',compact('details'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
         return view('details.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $request->validate([
            'Contact_Name' => 'required',
            'Mobile' => 'required',
        ]);
      
        contactManager::create($request->all());
       
        return redirect()->route('details.index')
                        ->with('success','Contact details saved successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ContactManager  $contactManager
     * @return \Illuminate\Http\Response
     */
    public function show(ContactManager $contactManager)
    {
          return view('details.show',compact('contactManager'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\ContactManager  $contactManager
     * @return \Illuminate\Http\Response
     */
    public function edit(ContactManager $contactManager)
    {
          return view('details.edit',compact('ContactManager'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ContactManager  $contactManager
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ContactManager $contactManager)
    {
        $request->validate([
            'Contact_Name' => 'required',
            'Mobile' => 'required',
        ]);
      
        $contactManager->update($request->all());
      
        return redirect()->route('details.index')
                        ->with('success','Contact Contact_Name changed successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ContactManager  $contactManager
     * @return \Illuminate\Http\Response
     */
    public function destroy(ContactManager $contactManager)
    {
        $contactManager->delete();
       
        return redirect()->route('details.index')
                        ->with('success','Contact  deleted!');
    }
}
