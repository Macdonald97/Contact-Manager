  
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New Contact</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(url('show')); ?>"> Back</a>
			
		
        </div>
    </div>
</div>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
 
    <form action="" a href="<?php echo e(url('details.show')); ?>"  method="POST">
        <?php echo csrf_field(); ?>

  
     <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Full names:</strong>
                <input type="text" name="name" class="form-control" placeholder="Enter your full names">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Mobile:</strong>
               <input type="text" name="Mobile" class="form-control" placeholder="Enter your contact details">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
		</br>
		</br>
                <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
   
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('details.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lucra\OneDrive\Desktop\xamp\htdocs\Laravel\ContManagerAssement\resources\views/details/create.blade.php ENDPATH**/ ?>